package com.example.study

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val edtName: EditText = findViewById(R.id.edtName)
        val btnNext: Button = findViewById(R.id.btnNext)

        val db = FirebaseFirestore.getInstance()

        btnNext.setOnClickListener {

            val name = edtName.text.toString().trim()

            if (name.isEmpty()) {
                Toast.makeText(
                    this,
                    "Please enter a name",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // CREATE
            val student = hashMapOf(
                "name" to name
            )

            db.collection("students")
                .add(student)
                .addOnSuccessListener { documentReference ->

                    val documentId = documentReference.id

                    Toast.makeText(
                        this,
                        "Student saved!",
                        Toast.LENGTH_SHORT
                    ).show()

                    // DATA PASSING
                    val intent = Intent(
                        this@MainActivity,
                        SecondActivity::class.java
                    )

                    intent.putExtra("USER_NAME", name)
                    intent.putExtra("DOCUMENT_ID", documentId)

                    startActivity(intent)
                }
                .addOnFailureListener { exception ->

                    Toast.makeText(
                        this,
                        "Error: ${exception.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
        }
    }
}