package com.example.study

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)

        val txtWelcome: TextView = findViewById(R.id.txtWelcome)
        val edtUpdateName: EditText = findViewById(R.id.edtUpdateName)
        val btnUpdate: Button = findViewById(R.id.btnUpdate)
        val btnDelete: Button = findViewById(R.id.btnDelete)

        val db = FirebaseFirestore.getInstance()

        // DATA PASSING
        val name = intent.getStringExtra("USER_NAME")
        val documentId = intent.getStringExtra("DOCUMENT_ID")

        txtWelcome.text = "Welcome, $name"

        edtUpdateName.setText(name)

        // READ
        if (documentId != null) {

            db.collection("students")
                .document(documentId)
                .get()
                .addOnSuccessListener { document ->

                    if (document.exists()) {

                        val savedName =
                            document.getString("name")

                        txtWelcome.text =
                            "Saved Student: $savedName"

                        edtUpdateName.setText(savedName)
                    }
                }
                .addOnFailureListener {

                    Toast.makeText(
                        this,
                        "Failed to read data",
                        Toast.LENGTH_SHORT
                    ).show()
                }
        }

        // UPDATE
        btnUpdate.setOnClickListener {

            val newName =
                edtUpdateName.text.toString().trim()

            if (newName.isEmpty()) {
                Toast.makeText(
                    this,
                    "Enter a new name",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            if (documentId != null) {

                db.collection("students")
                    .document(documentId)
                    .update("name", newName)
                    .addOnSuccessListener {

                        txtWelcome.text =
                            "Saved Student: $newName"

                        Toast.makeText(
                            this,
                            "Student updated!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    .addOnFailureListener { exception ->

                        Toast.makeText(
                            this,
                            "Update failed: ${exception.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
            }
        }

        // DELETE
        btnDelete.setOnClickListener {

            if (documentId != null) {

                db.collection("students")
                    .document(documentId)
                    .delete()
                    .addOnSuccessListener {

                        Toast.makeText(
                            this,
                            "Student deleted!",
                            Toast.LENGTH_SHORT
                        ).show()

                        finish()
                    }
                    .addOnFailureListener { exception ->

                        Toast.makeText(
                            this,
                            "Delete failed: ${exception.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
            }
        }
    }
}